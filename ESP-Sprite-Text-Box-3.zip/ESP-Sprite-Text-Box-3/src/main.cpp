/*  
 Test the tft.print() viz embedded tft.write() function

 This sketch used font 2, 4, 7

 Make sure all the display driver and pin connections are correct by
 editing the User_Setup.h file in the TFT_eSPI library folder.

 #########################################################################
 ###### DON'T FORGET TO UPDATE THE User_Setup.h FILE IN THE LIBRARY ######
 #########################################################################
 */


#include <TFT_eSPI.h> // Graphics and font library for ILI9341 driver chip
#include <SPI.h>


#define  TFT_BL 5 

TFT_eSPI tft = TFT_eSPI();  // Invoke library
TFT_eSprite spr = TFT_eSprite(&tft); // Sprite object
TFT_eSprite sprText = TFT_eSprite(&tft); // Sprite object
String TestText[20];
uint32_t TextOffset = 0;

void SetTextInBox(TFT_eSprite  lcd);
void SetTextBox(TFT_eSprite  lcd, int32_t x, int32_t y, int32_t w, int32_t h  );
void SetText();

void setup(void) {
  Serial.begin(115200);
  pinMode(TFT_BL, OUTPUT);
  tft.init();
  tft.setRotation(1);
  tft.fillScreen(TFT_PURPLE);
  spr.setColorDepth(8);

  SetTextBox(spr, 0, 0, 250, 200);

}

void loop() {
  SetText();
 
 SetTextInBox(sprText);
 delay(1500);
 if (TextOffset++ > 19)
 TextOffset = 0;
  }

void SetTextInBox(TFT_eSprite  lcd)
{
lcd.createSprite(250 - 12, 200 - 20);
lcd.fillSprite(TFT_NAVY);
lcd.setTextColor(TFT_GOLD, TFT_NAVY);

int Zufall = 5; //random(19);

for (int i = 0; i < Zufall; i++)
{
lcd.setCursor(25, 10 + 12 * i);
lcd.println(TestText[i + TextOffset]);
}
lcd.pushSprite(25 +6, 10 + 6);

lcd.deleteSprite();
}

void SetTextBox(TFT_eSprite  lcd, int32_t x, int32_t y, int32_t w, int32_t h  )
{
lcd.createSprite(250, 200); 
lcd.fillSprite(TFT_NAVY);
lcd.drawRect(x, y, w, h, TFT_GREEN);
lcd.drawRect(x + 1, y + 1, w - 2, h - 2, TFT_GOLD);
lcd.drawRect(x + 2, y + 2, w - 4, h - 4, TFT_GREENYELLOW);
lcd.drawRect(x + 3, y + 3, w - 6, h - 6, TFT_RED);
/*
SetTextBox(lcd, TestText[0] , 1 );
SetTextBox(lcd, TestText[1] , 2 );
SetTextBox(lcd, TestText[2] , 3 );
*/
lcd.pushSprite(25, 10);
lcd.deleteSprite();

}


char *letters = "abcdefghijklmnopqrstuvwxyz0123456789";

char SetRandLetter()
{
 byte randomValue = random(0, 37);
   char letter = randomValue + 'a';
   if(randomValue > 26)
      letter = (randomValue - 26) + '0';
return (letter);
}





void SetText()
{
TestText[0] = "Hallo ";
TestText[1] = "this is Daisy";
TestText[2] = "my Cat";
TestText[3] = "her Buddy is Teddy";
TestText[4] = "a British Short Hair";
TestText[5] = "and Lilly";
TestText[6] = "a cute Bengale";
TestText[7] = "Frida and Ronny";
TestText[8] = "Lillys Kids";
TestText[9] = "!!!!!!!!!";
TestText[10] = "111111111";
TestText[11] = "2222222222";
TestText[12] = "3333333333333";
TestText[13] = "4444444444";
TestText[14] = "555555555";
TestText[15] = "6666666666";
TestText[16] = "7777777777";
TestText[17] = "88888888";
TestText[18] = "99999999999";
}


